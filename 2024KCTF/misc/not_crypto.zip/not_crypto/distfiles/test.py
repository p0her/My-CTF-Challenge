import random
import hashlib

def stage1():
    MAGIC = 'p0her'
    x = ord(MAGIC[0]) << 7 if MAGIC else 0
    for c in map(ord, MAGIC):
        x = ((1000003 * x) ^ c) & 0xFFFFFFFFFFFFFFFF
    x ^= len(MAGIC)
    a = -2 if x == -1 else x

    x = a
    y = MAGIC
    
    random.seed(x, version=1)
    state1 = random.getrandbits(0x10001)
    random.seed(y, version=1)
    state2 = random.getrandbits(0x10001)

    assert state1 == state2

def stage2():
    MAGIC = b'magic'
    sha512 = hashlib.sha512()
    sha512.update(MAGIC)

    hack = MAGIC + sha512.digest()
    x = int.from_bytes(hack, byteorder='big')
    y = MAGIC

    random.seed(x)
    state1 = random.getrandbits(0x10001)
    random.seed(y)
    state2 = random.getrandbits(0x10001)

    assert state1 == state2

if __name__ == '__main__':
    stage1()
    stage2()